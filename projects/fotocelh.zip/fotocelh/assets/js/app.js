var offset = 10;

$(document).ready(function() {
    $('.js-view-more').on('click', function(event) {;
        viewMoreImages(offset);
    });
});

function viewMoreImages(currentOffset) {
    var images = $('.b-results-list__list-element').toArray();
    var max = currentOffset + 10;
    for (var i = currentOffset; i < max; i++) {
        if (images[i]) {
            var elementClassName = images[i].className;
            var newClassName = elementClassName.replace("hide", "");
            images[i].className = newClassName + ' visible';
        }
    }
    offset = offset + 10;
}

<?php
$imageId = (isset($_GET['id']) && !filter_var($_GET['id'], FILTER_VALIDATE_INT) === false) ? $_GET['id'] : '';
if ($imageId !== '') {
    $mysqli = new mysqli("localhost", "root", "", "albums_fotos");
    if ($mysqli->connect_errno) {
        echo "Fallo al conectar con la base de datos";
    }
    $mysqli->set_charset("utf8");
    $stmt = $mysqli->prepare("SELECT * FROM imatge WHERE id = ?");
    if ($stmt !== false) {
        $stmt->bind_param("i", $imageId);
        $stmt->execute();
        $result = $stmt->get_result();
        $image = $result->fetch_array(MYSQLI_ASSOC);
    }

    mysqli_close($mysqli);
}

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name=viewport content="width=device-width, initial-scale=1">
  <title>FOTOCELH</title>
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap-theme.min.css">
  <link rel="stylesheet" type="text/css" href="../assets/css/app.css?version=3.2">
</head>
<body>
  <header id="header" class="header">
    <a class="b-header__link" href="http://fotocelh.dev/" title="home">fotoclh</a>
  </header>
  <div class="container">
    <div class="row row-with-top-margin">
      <div class="col-xs-12 col-xs-offset-0">
        <?php if (isset($image) && !empty($image)) {?>
        <div class="col-md-6">
          <img class="img-responsive b-image-found__image" src="../assets/img/<?php echo $image['carpeta']; ?>/<?php echo $image['subcarpeta']; ?>/<?php echo $image['imatge']; ?>" alt="Example"/>
        </div>
        <div class="col-md-6">
           <dl class="b-image-information">
            <dt>Número de la fotografia:</dt>
            <dd><?php echo (!is_null($image['fotografia_num']) ? $image['fotografia_num'] : 'No s\'ha especificat'); ?></dd>
            <dt>Carpeta</dt>
            <dd><?php echo (!is_null($image['carpeta']) ? $image['carpeta'] : 'No s\'ha especificat'); ?></dd>
            <dt>Tipus:</dt>
            <dd><?php echo (!is_null($image['tipo']) ? $image['tipo'] : 'No s\'ha especificat'); ?></dd>
            <dt>Autor</dt>
            <dd><?php echo (!is_null($image['autor']) ? $image['autor'] : 'No s\'ha especificat'); ?></dd>
            <dt>Font</dt>
            <dd><?php echo (!is_null($image['font']) ? $image['font'] : 'No s\'ha especificat'); ?></dd>
            <dt>Data</dt>
            <dd><?php echo (!is_null($image['data']) ? $image['data'] : 'No s\'ha especificat'); ?></dd>
          </dl>
          <p class="b-image-description"><?php echo (!is_null($image['descripcio']) ? $image['descripcio'] : 'Aquesta imatge no disposa de cap descripció.'); ?></p>
        </div>
        <?php } else {?>
          <h2>La fotografia que has sol·licitat no existeix en la base de dades.</h2>
        <?php }?>
      </div>
    </div>
  </div>
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/bootstrap.min.js" type="text/javascript" charset="utf-8"></script>
<script src="../assets/js/app.js" type="text/javascript" charset="utf-8"></script>
</body>
</html>

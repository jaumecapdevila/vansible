<?php
$searchFilter = (isset($_POST['searchFilter'])) ? filter_var($_POST['searchFilter'], FILTER_SANITIZE_SPECIAL_CHARS) : 'descripcio';
$searchParameter = (isset($_POST['sarchImage']) && $_POST['sarchImage'] !== '') ? filter_var($_POST['sarchImage'], FILTER_SANITIZE_SPECIAL_CHARS) : '';
if ($searchParameter !== '') {
    $mysqli = new mysqli("localhost", "root", "", "albums_fotos");
    if ($mysqli->connect_errno) {
        echo "Error al connectar-se amb la base de dades";
    }
    $mysqli->set_charset("utf8");
    $likeCondition = '%' . $searchParameter . '%';
    $stmt = $mysqli->prepare("SELECT * FROM imatge WHERE $searchFilter LIKE ? LIMIT 32");
    if ($stmt !== false) {
        $stmt->bind_param("s", $likeCondition);
        $stmt->execute();
        $result = $stmt->get_result();
        $foundImages = array();
        while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
            array_push($foundImages, $row);
        }
    }
    mysqli_close($mysqli);
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name=viewport content="width=device-width, initial-scale=1">
  <title>FOTOCELH</title>
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" type="text/css" href="./assets/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="./assets/css/bootstrap-theme.min.css">
  <link rel="stylesheet" type="text/css" href="./assets/css/app.css?version=3.2">
</head>
<body>
<header id="header" class="header">
  <a class="b-header__link" href="http://fotocelh.dev/" title="home">fotocelh</a>
  <span data-toggle="modal" data-target="#searchModal" id="search-icon" class="glyphicon glyphicon-search" aria-hidden="true"></span>
</header>
<div id="searchModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h2 class="modal-title">Cerca una fotografia</h2>
      </div>
      <div class="modal-body">
        <form action="index.php" method="POST">
        <div class="form-group">
        <label for="searchFilter">Filtrar la cerca per:</label>
          <select name="searchFilter" class="form-control">
            <option value="descripcio">Descripció</option>
            <option value="data">Data</option>
            <option value="autor">Autor</option>
            <option value="font">Font</option>
            <option value="fotografia_num">Número de la fotografia</option>
            <option value="carpeta">Nom de la carpeta</option>
            <option value="subcarpeta">Nom de la subcarpeta</option>
          </select>
        </div>
          <div class="form-group">
            <label for="sarchImage">Introdueix la teva cerca:</label>
            <input type="text" class="form-control" name="sarchImage" id="sarchImage" placeholder="">
          </div>
          <button id="submitFormButton" type="submit" class="btn btn-default">Cerca</button>
        </form>
      </div>
    </div>
  </div>
</div>
<div class="container">
  <div class="row">
    <div class="col-xs-12 col-xs-offset-0">
    <?php if (isset($foundImages)) {?>
      <h2>Resultats de la cerca:</h2>
      <hr>
      <?php if (!empty($foundImages)) {?>
        <?php $cont = 0;?>
        <ul class="b-images-found__list">
        <?php foreach ($foundImages as $foundImage) {?>
          <?php if($cont > 10) { ?>
            <li class="b-results-list__list-element hide">
              <div class="overlay"><a href="http://fotocelh.dev/foto/?id=<?php echo $foundImage['id']; ?>" class="more-information"><span class="glyphicon glyphicon-info-sign"></span></a></div>
              <img class="img-responsive b-image-found__image" src="../assets/img/<?php echo $foundImage['carpeta']; ?>/<?php echo $foundImage['subcarpeta']; ?>/<?php echo $foundImage['imatge']; ?>" alt="Fotografia"/>
            </li>
          <?php } else { ?>
            <li class="b-results-list__list-element visible">
              <div class="overlay"><a href="http://fotocelh.dev/foto/?id=<?php echo $foundImage['id']; ?>" class="more-information"><span class="glyphicon glyphicon-info-sign"></span></a></div>
              <img class="img-responsive b-image-found__image" src="../assets/img/<?php echo $foundImage['carpeta']; ?>/<?php echo $foundImage['subcarpeta']; ?>/<?php echo $foundImage['imatge']; ?>" alt="Fotografia"/>
            </li>
          <?php }?>
          <?php $cont++;?>
        <?php }?>
        </ul>
        <a href="javascript:void(0);" title="Veure més" class="c-btn js-view-more">Veure més</a>
        <?php } else {?>
          <h2>No s'ha trobat cap resultat per la teva cerca...</h2>
        <?php }?>
    <?php } else {?>
      <h2>Fes servir la lupa per a realitzar una cerca</h2>
    <?php }?>
    </div>
  </div>
</div>
<script src="./assets/js/jquery.min.js"></script>
<script src="./assets/js/bootstrap.min.js" type="text/javascript" charset="utf-8"></script>
<script src="./assets/js/app.js" type="text/javascript" charset="utf-8"></script>
</body>
</html>

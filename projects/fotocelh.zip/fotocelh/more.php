<?php
$actualOffset = $_POST['offset'];
die(var_dump($actualOffset));
$mysqli = new mysqli("localhost", "root", "toor", "albums_fotos");
if ($mysqli->connect_errno) {
    echo "Fallo al conectar con la base de datos";
}
$mysqli->set_charset("utf8");
$stmt = $mysqli->prepare("SELECT * FROM imatge LIMIT 5 offset ?");
if ($stmt !== false) {
    $stmt->bind_param("i", $imageId);
    $stmt->execute();
    $result = $stmt->get_result();
    $image = $result->fetch_array(MYSQLI_ASSOC);
}

mysqli_close($mysqli);
